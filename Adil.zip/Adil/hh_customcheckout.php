<?php
class Adil extends Module
{

    public function __construct()
    {
        $this->name = 'Adil';
        $this->tab = 'others';
        $this->version = '0.1.0';
        $this->author = 'hhennes';
        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->l('Sample checkout step module');
        $this->description = $this->l('Sample module for adding a custom step in checkout');
    }

}