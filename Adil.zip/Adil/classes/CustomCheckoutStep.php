<?php

use Symfony\Component\Translation\TranslatorInterface;

class CustomCheckoutStep extends AbstractCheckoutStep
{

    /** @var Adil */
    protected $module;

    /** @var string $serviceName */
    protected $serviceName;

    /** @var string $responsableName */
    protected $responsableName;

    public function __construct(
        Context $context,
        TranslatorInterface $translator,
        Adil $module
    )
    {
        parent::__construct($context, $translator);
        $this->module = $module;
        $this->setTitle('Test de nouvelle étape');
    }


    /**
     * Récupération des données à persister
     *
     * @return array
     */
    public function getDataToPersist()
    {
        return array(
            'service_name' => $this->serviceName,
            'responsable_name' => $this->responsableName,
        );
    }

    /**
     * Restoration des données persistées
     *
     * @param array $data
     * @return $this|AbstractCheckoutStep
     */
    public function restorePersistedData(array $data)
    {
        if (array_key_exists('service_name', $data)) {
            $this->serviceName = $data['service_name'];
        }

        if (array_key_exists('responsable_name', $data)) {
            $this->responsableName = $data['responsable_name'];
        }

        return $this;
    }

    /**
     * Traitement de la requête ( ie = Variables Posts du checkout
     * @param array $requestParameters
     * @return $this
     */
    public function handleRequest(array $requestParameters = array())
    {
        //Si les informations sont postées assignation des valeurs
        if (isset($requestParameters['submitCustomStep'])) {
            $this->serviceName = $requestParameters['service_name'];
            $this->responsableName = $requestParameters['responsable_name'];

            //Passage à l'étape suivante
            $this->setComplete(true);

            //Code 1.7.6
            if (version_compare(_PS_VERSION_, '1.7.6') > 0) {
                $this->setNextStepAsCurrent();
            } else {
                $this->setCurrent(false);
            }
        }

        return $this;
    }

    /**
     * Affichage de la step
     *
     * @param array $extraParams
     * @return string
     */
    public function render(array $extraParams = [])
    {

        //Assignation des informations d'affichage
        $defaultParams = array(
            //Informations nécessaires
            'identifier' => 'test',
            'position' => 3, //La position n'est qu'indicative ...
            'title' => $this->getTitle(),
            'step_is_complete' => (int)$this->isComplete(),
            'step_is_reachable' => (int)$this->isReachable(),
            'step_is_current' => (int)$this->isCurrent(),
            //Variables custom
            'serviceName' => $this->serviceName,
            'responsableName' => $this->responsableName,
        );

        $this->context->smarty->assign($defaultParams);
        return $this->module->display(
            _PS_MODULE_DIR_ . $this->module->name,
            'views/templates/front/customCheckoutStep.tpl'
        );
    }

}